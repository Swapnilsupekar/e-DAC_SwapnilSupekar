import java.util.Scanner;
public class Solution8 {

	public static void main(String[] args) {

        float amaunt, rate, time, simple_interest;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the Principal Amaunt : ");
        amaunt = sc.nextFloat();
        System.out.print("Enter the Rate of interest in percentage: ");
        rate = sc.nextFloat();
        System.out.print("Enter the Time period in year  : ");
        time = sc.nextFloat();
        sc.close();
        simple_interest = (amaunt * rate * time) / 100;
        System.out.print("Simple Interest is: " +simple_interest);

	}

}
