import java.util.Scanner;
public class Solution4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter value for two variable");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		byte c=0;
		byte d=0;
		c=(byte) a;
		 d=(byte) b;
		 System.out.println(" c = "+c +" d ="+d);
		 sc.close();
		
		
		

	}

}
