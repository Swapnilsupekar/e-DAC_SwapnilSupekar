import java.util.Scanner;
public class Solution11 {

	public static void main(String[] args) {
		 System.out.println("Enter the value of first_number and second_number");  
	        Scanner sc = new Scanner(System.in);  
	        int first_num = sc.nextInt();  
	        int second_num = sc.nextInt();  
	        System.out.println("before swapping numbers: "+first_num +" "+ second_num);  
	        first_num = first_num + second_num;   
	        second_num = first_num - second_num;   
	        first_num = first_num - second_num;   
	        System.out.println("After swapping: "+first_num +"  " + second_num); 
	        sc.close();
	}

}
