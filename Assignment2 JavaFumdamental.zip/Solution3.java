import java.util.Scanner;
public class Solution3 {

	public static void main(String[] args) {
		
Scanner sc = new Scanner(System.in);
System.out.println("Enter the value for x");
int x=sc.nextInt();
int y,z;
y = (x*x + 3*x -7);
System.out.println("y =" + y);

y= (x++ + ++x);
System.out.println("y =" + y +" x = "+x);

z = (x++ - --y - --x + x++);
System.out.println("x ="+x + "y =" + y+" z = "+z);

boolean a=false,b=false,c=false;
c = a && b ||!(a || b );
System.out.println("c=" + c);

sc.close();
	}

}
