import java.util.Scanner;
public class Solution6 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of Radius of circle = ");
		double radius=sc.nextDouble();
		double area=(3.14*radius*radius);
		double circumference=(3.14*2*radius);
		System.out.println("area ="+area);
		System.out.println("circumference ="+circumference);
		sc.close();
		

	}

}
