import java.util.Scanner;
public class Solution7 {

	public static void main(String[] args)
	{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the subject1 marks out of 100 marks = ");
int sub1=sc.nextInt();
System.out.println("Enter the subject2 marks out of 100 marks = ");
int sub2=sc.nextInt();
System.out.println("Enter the subject3 marks out of 100 marks = ");
int sub3=sc.nextInt();
System.out.println("Enter the subject4 marks out of 100 marks = ");
int sub4=sc.nextInt();
System.out.println("Enter the subject5 marks out of 100 marks = ");
int sub5=sc.nextInt();
float percentage=((sub1 +sub2 + sub3 + sub4 + sub5)/5);
System.out.println("[percentage mark = "+percentage+"% ]");
sc.close();


	}

}
