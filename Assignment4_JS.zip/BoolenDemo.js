let a = true;
console.log(a, typeof a);

if(a)
{
    console.log(" i m true");
}

let some = false;
while(some)
{
    console.log("i m boolean value in while loop");
}

for(var i=1;i==true;i++)
{
    console.log("i m boolean value in while loop");
}

var tans = false;
var num =3;
do{
    console.log("I m boolean value in do while loop");
num--;
}
while(tans);