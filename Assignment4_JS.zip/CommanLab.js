var Monday = "Aptitude";
let tuesday = "Group Study";
const wednesday = "Communication Activity";

console.log(Monday);
console.log(tuesday);
console.log(wednesday);

tuesday= "Enjoying NodeJS sessions";
console.log(tuesday);

wednesday="22";         //error
console.log(wednesday);

let tuesday = "cdac mumbai";        //error
console.log(tuesday);

let s =28;
for(var i=1;i<5;i++)
{
    let s = i+55;
console.log(s);
}

let n=5;
//const res =22; /* can't decrease value of res */
var res = 24;
while(n>0){
    var tans = res*res;
    res--;
    console.log(tans)
    n--;
}

